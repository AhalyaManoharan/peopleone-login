<?php
include('config.php');
$error = '';
$success = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = htmlspecialchars(trim($_POST['email']));
    $new_password = htmlspecialchars(trim($_POST['new_password']));
    $confirm_password = htmlspecialchars(trim($_POST['confirm_password']));

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } elseif (strlen($new_password) < 6) {
        $error = "Password must be at least 6 characters long.";
    } elseif ($new_password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {
        $stmt = $conn->prepare("SELECT * FROM users WHERE email=?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $user = $result->fetch_assoc();

            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE users SET password=? WHERE email=?");
            $stmt->bind_param("ss", $hashed_password, $email);

            if ($stmt->execute()) {
                $success = "Password has been reset successfully. You can now <a href='index.php'>log in</a>.";
            } else {
                $error = "Failed to reset password. Please try again.";
            }
        } else {
            $error = "No account found with that email address.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <title>Reset Password</title>
</head>
<body>

    <div class="container register-form">
        <div class="form-register text-center">
            <div>
                <img src="img/logo.png" class="w-20 pb-3">
            </div>        

            <?php if (!empty($error)) { echo "<p style='color:red;'>$error</p>"; } ?>
            <?php if (!empty($success)) { echo "<p style='color:green;'>$success</p>"; } ?>

            <h2>Reset Password</h2>

            <form action="" method="POST" autocomplete="off">
                <div class="mb-3">
                    <div class="input-container">
                        <input type="email" id="email" name="email" placeholder=" " required>
                        <label for="email">Email Address</label>
                    </div>
                </div>

                <div class="mb-3">
                    <div class="input-container">
                        <input type="password" id="new_password" name="new_password" placeholder=" " required>
                        <label for="new_password">New Password</label>
                    </div>
                </div>

                <div class="mb-3">
                    <div class="input-container">
                        <input type="password" id="confirm_password" name="confirm_password" placeholder=" " required>
                        <label for="confirm_password">Confirm Password</label>
                    </div>
                </div>

                <div class="mb-4 submit-btn">
                    <input type="submit" value="Reset Password" class="btn btn-primary" style="width:180px;">
                </div>
            </form>
        </div>
    </div>

</body>
</html>
