<?php
session_start();
include('config.php');

if (!isset($_SESSION['username'])) {
    if (isset($_COOKIE['remember_me'])) {
        $token = $_COOKIE['remember_me'];
        
        $stmt = $conn->prepare("SELECT * FROM users WHERE remember_token=?");
        $stmt->bind_param("s", $token);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $user = $result->fetch_assoc();
            $_SESSION['username'] = $user['username'];
        } else {
            header("Location: index.php");
            exit;
        }
    } else {
        header("Location: index.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <title>Dashboard</title>
</head>
<body>
    
    <div class="container dashboard">
         <div class="dashboard-login text-center">
            <div>
               <img src="img/logo.png" class="w-20 pb-3" >
            </div>
            <h2>Welcome, <br><?php echo $_SESSION['username']; ?>😊! </h2>
            <div class="pt-4">
            <a class="logout-btn p-3" href="logout.php">Logout</a>    </div>
           
            
         </div>
      </div>
</body>
</html>
    