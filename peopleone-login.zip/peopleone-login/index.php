<?php
session_start();
include('config.php');

$error = '';

if (isset($_POST['btn-sub'])) { 
       $username_email = htmlspecialchars(trim($_POST['username_email']));
    $password = htmlspecialchars(trim($_POST['password']));
    $remember_me = isset($_POST['remember_me']);


    if (empty($username_email) || empty($password)) {
        $error = "All fields are required.";
    } else {
        $stmt = $conn->prepare("SELECT * FROM users WHERE username=? OR email=?");
        $stmt->bind_param("ss", $username_email, $username_email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $user = $result->fetch_assoc();

            if (password_verify($password, $user['password'])) {
                $_SESSION['username'] = $user['username'];
                if ($remember_me) {
                    $token = bin2hex(random_bytes(16)); 
                    $stmt = $conn->prepare("UPDATE users SET remember_token=? WHERE id=?");
                    $stmt->bind_param("si", $token, $user['id']);
                    $stmt->execute();

                    setcookie('remember_me', $token, time() + (86400 * 30), "/");
                }
                header("Location: dashboard.php");
                exit();
            } else {
                $error = "Incorrect password.";
            }
        } else {
            $error = "No account found with that email. Register First..";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <title>Login</title>
</head>
<body>
    <div class="container login-form">
        <div class="form-login text-center">
            <div>
                <img src="img/logo.png" class="w-20 pb-3" >
            </div>
            <h2>Login</h2>
            <?php if (!empty($error)) { echo "<p style='color:red;'>$error</p>"; } ?>
            <form id="loginForm" action="index.php" method="POST" autocomplete="off">
                <div class="d-flex justify-content-between gap-3">
                    <div style="width: 100%;">
                        <div class="input-container">
                            <input type="text" placeholder=" " name="username_email" required>
                            <label>Enter Email </label>
                        </div>
                        <p class="error-message" id="email-error"></p>
                    </div>
                </div>
                <div class=" mb-2 d-flex justify-content-between gap-3">
                    <div style="width: 100%;">
                        <div class="input-container">
                            <input type="password" placeholder=" " name="password" required>
                            <label>Enter Password</label>
                        </div>
                        <p class="error-message" id="password-error"></p>
                    </div>
                </div>
                <div class=" mb-3 d-flex gap-2">
                    <div><input type="checkbox" name="remember_me"></div>
                    <div> Remember Me</div>
                </div>
                <div class="p-2 mb-4 d-flex justify-content-between align-item-center submit-btn">
                    <input type="submit" value="Login" name="btn-sub" class="btn btn-primary">
                </div>
                <div>
                    <p>Forget <a href="reset_password.php">Password?</a></p>
                </div>
                <div>
                    <p>Don't have an Account? <a href="register.php">Register Now</a></p>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
