<?php
session_start();
include('config.php');
$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = htmlspecialchars(trim($_POST['username']));
    $email = htmlspecialchars(trim($_POST['email']));
    $password = htmlspecialchars(trim($_POST['password']));

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters.";
    } else {
        $stmt = $conn->prepare("SELECT * FROM users WHERE username=? OR email=?");
        $stmt->bind_param("ss", $username, $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $error = "Username or Email already taken.";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $username, $email, $hashed_password);

            if ($stmt->execute()) {
                echo "<script>
                    alert('Registration successful! Redirecting to login page...');
                    window.location.href = 'index.php';
                </script>";
                exit();
            }
             else {
                $error = "Error in registration. Try again.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <link rel="stylesheet" href="css/style.css">
    <title>Register</title>
</head>
<body>
    <div class="container register-form">
        <div class="form-register text-center">
            <div>
                <img src="img/logo.png" class="w-20 pb-3">
            </div>      
            <h2>Register</h2>
            <form id="registerForm" action="register.php" method="POST" autocomplete="off">
                <div class="mb-3">
                    <div class="input-container">
                        <input type="text" id="username" name="username" placeholder=" " required>
                        <label for="username">Username</label>
                    </div>
                    <p class="error-message" id="username-error" aria-live="polite"></p>
                </div>

                <div class="mb-3">
                    <div class="input-container">
                        <input type="email" id="email" name="email" placeholder=" " required>
                        <label for="email">Email</label>
                    </div>
                    <p class="error-message" id="email-error" aria-live="polite"></p>
                </div>

                <div class="mb-3">
                    <div class="input-container">
                        <input type="password" id="password" name="password" placeholder=" " required>
                        <label for="password">Password</label>
                    </div>
                    <p class="error-message" id="password-error" aria-live="polite"></p>
                </div>

                <div class="mb-4 submit-btn">
                    <input type="submit" value="Register" class="btn btn-primary">
                </div>
                <div>
                    <p>Already have an account? <a href="index.php">Login</a></p>
                </div>
                <p><?php echo isset($error) ? $error : ''; ?></p>
            </form>
        </div>
    </div>

    <script>
    $(document).ready(function() {
        $('#registerForm').on('submit', function(e) {
            e.preventDefault();

            var username = $('input[name="username"]').val();
            var email = $('input[name="email"]').val();
            var password = $('input[name="password"]').val();
            var usernameError = validateUsername(username);
            var emailError = validateEmail(email);
            var passwordError = validatePassword(password);

            $('#username-error').html(usernameError);
            $('#email-error').html(emailError);
            $('#password-error').html(passwordError);

            if (!usernameError && !emailError && !passwordError) {
                this.submit();
            }
        });

        function validateUsername(username) {
            return username.length < 3 ? 'Username must be at least 3 characters long.' : '';
        }

        function validateEmail(email) {
            var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailPattern.test(email) ? '' : 'Please enter a valid email address.';
        }

        function validatePassword(password) {
            var passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
            return passwordPattern.test(password) ? '' : 'Password must be at least 8 characters, with 1 uppercase letter, 1 number, and 1 special character.';
        }
    });
    </script>

</body>
</html>
